import Interop.InteropTests;
import SimpleUnitTest.SimpleUnitTest;
import javafx.application.Application;
import javafx.stage.Stage;

public class JavaFXTests extends SimpleUnitTest {
    public static void main(String[] args) {
        it("allows to use JavaFx", () -> {
            // simple check assuring JavaFx is included.
            assertTrue(Application.class.getName().equals("javafx.application.Application"));
            assertTrue(Stage.class.getName().equals("javafx.stage.Stage"));
        });
    }
}
