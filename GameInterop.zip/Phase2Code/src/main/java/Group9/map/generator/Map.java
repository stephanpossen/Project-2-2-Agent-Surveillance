package Group9.map.generator;

import java.io.Serializable;


public class Map implements Serializable {
    
    private final Room[] rooms;
    private final char map[][];

    /***
     * Representation of a dungeon.
     * @param rooms Rooms of the dungeon
     * @param map Character map of the dungeon
     */
    public Map(Room[] rooms, char[][] map) {
        this.rooms = rooms;
        this.map = map;
    }

    /***
     * Returns a copy of the dungeon's map
     * @return Character map of the dungeon
     */
    public char[][] getMap() {
        return map.clone();
    }

    /**
     * Returns a copy of the rooms within the dungeon
     * @return An array of dungeon rooms.
     */
    public Room[] getRooms() {
        return rooms.clone();
    }

    @Override
    public String toString() {
        String mapString = "";
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                mapString += map[i][j];
            }
            mapString += "\n";
        }
        return mapString;
    }
    
}
