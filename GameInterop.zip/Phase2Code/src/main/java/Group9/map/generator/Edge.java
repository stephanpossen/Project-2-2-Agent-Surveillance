package Group9.map.generator;

public class Edge {
    
    private final Room source;
    private final Room target;

    /**
     * Create Edge between two rooms
     * @param source First Room
     * @param target Second Room
     */
    public Edge(Room source, Room target) {
        this.source = source;
        this.target = target;
    }
    
    /***
     * Returns the distance between two rooms
     * @return The distance between two rooms
     */
    public double distance() {
        return source.distance(target);
    }

    /**
     * Returns the first room
     * @return First room
     */
    public Room getFirst() {
        return source;
    }

    /**
     * Returns the second room
     * @return Second room
     */
    public Room getSecond() {
        return target;
    }

    @Override
    public String toString() {
        return "[" + source + ", " + target + ", distance: " + source.distance(target) + "]";
    }

}
