package Interop.Percept.Sound;

/**
 * List of all possible sound types.
 */
public enum SoundPerceptType {
    Noise, Yell;
}
