package Interop.Percept.Scenario;

public enum GameMode {
    CaptureOneIntruder, CaptureAllIntruders;
}
