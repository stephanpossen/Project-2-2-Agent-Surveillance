package Interop.Percept.Smell;

/**
 * Lists all possible smell types.
 */
public enum SmellPerceptType {
    Pheromone1, Pheromone2, Pheromone3, Pheromone4, Pheromone5;
}
