package Interop.Action;

public interface IntruderAction extends Action {
}
