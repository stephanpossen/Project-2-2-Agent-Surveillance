package Interop.Action;

public interface Action {
}
