package Interop.Action;

/**
 * This class represents an intention to yell issued by a guard agent.
 */
public final class Yell implements Action, GuardAction {
}
