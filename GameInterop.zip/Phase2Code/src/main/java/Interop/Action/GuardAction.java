package Interop.Action;

public interface GuardAction extends Action {

}
