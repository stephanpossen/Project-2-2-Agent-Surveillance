package Group7.gui2;

import Group7.agent.container.IntruderContainer;
import Group7.map.dynamic.DynamicObject;
import Group7.agent.container.GuardContainer;
import javafx.application.Application;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.*;
import java.util.List;
import java.util.Random;

public class Gui extends Application {
<<<<<<< Updated upstream:src/main/java/Group7/gui2/Gui.java
    private File mapFile = new File("./src/main/java/Group7/map/maps/test_2.map");
=======
    private File mapFile = new File("./src/main/java/Group9/map/maps/generatedMap.map");
>>>>>>> Stashed changes:src/main/java/Group9/gui2/Gui.java
    private MainController mainController = new MainController(this,mapFile,true);
    private MainScene scene = new MainScene(new StackPane(), mainController.getGame().getGameMap(),this);
    private Stage primary = new Stage();

    public static void Gui(String[] args) {

        launch(args);

    }

    @Override
    public void start(Stage primaryStage) {

        //generateMapfromDrawing();
        primaryStage.setHeight(GuiSettings.defaultHeight);
        primaryStage.setWidth(GuiSettings.defaultWidth);
        primaryStage.setTitle("Orwells Dream");
        primaryStage.setScene(scene);
        primary = primaryStage;
        primaryStage.show();
        scene.rescale();
        Thread thread = new Thread(mainController);
        thread.start();
        primaryStage.setOnCloseRequest(event -> {
            System.out.println("See Ya");
            mainController.kill();
        });
    }


    public void generateMapfromDrawing() {

    }


    public void drawMovables(List<GuardContainer> guards, List<IntruderContainer> intruders, List<DynamicObject<?>> objects){
        scene.drawMovables(guards, intruders, objects);
    }
    public void activateHistory(){
        if(!scene.isHasHistory()){
            scene.activateHistory();
        }
    }
    public Stage getPrimary() {
        return primary;
    }

    public MainController getMainController() {
        return mainController;
    }
    public void restartGame(boolean generateHistory){
        mainController.kill();
        mainController = new MainController(this,mapFile, generateHistory);
        Thread thread = new Thread(mainController);
        thread.start();
    }

    public void setMapFile(File mapFile) {
        this.mapFile = mapFile;
    }

    public File getMapFile() {
        return mapFile;
    }
}
