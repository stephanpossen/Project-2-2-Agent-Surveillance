package Group7;

import Group7.agent.factories.DefaultAgentFactory;
import Group7.map.parser.Parser;


public class Main {

    public static void main(String[] args) {

<<<<<<< Updated upstream:src/main/java/Group7/Main.java
        Game game = new Game(Parser.parseFile("./src/main/java/Group7/map/maps/testWindow.map"), new DefaultAgentFactory(), false);
=======
        long startTime = System.currentTimeMillis();
        Game game = new Game(Parser.parseFile("./src/main/java/Group9/map/maps/test_2.map"), new DefaultAgentFactory(), false);
>>>>>>> Stashed changes:src/main/java/Group9/Main.java
        game.run();
        System.out.printf("The winner is: %s\n", game.getWinner());
        long estimatedTime = System.currentTimeMillis() - startTime;
        System.out.println("The game took " + estimatedTime/1000 + " seconds");

    }


}
