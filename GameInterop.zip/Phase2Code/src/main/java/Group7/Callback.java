package Group7;

public interface Callback<T> {

    void call(T v);

}
