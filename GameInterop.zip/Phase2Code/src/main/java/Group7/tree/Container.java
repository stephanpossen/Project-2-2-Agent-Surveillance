package Group7.tree;

public interface Container<T> {

    T getContainer();

}
