package multiagentsurveillance.entities.creatures;

import java.awt.Graphics;

import multiagentsurveillance.Game;
import multiagentsurveillance.gfx.Assets;

public class Tower extends Creature {

	public Tower(Game game, int x, int y) {
		super(x, y, Creature.TOWER_WIDTH, Creature.TOWER_HEIGHT);
	}

	@Override
	public void tick() {

		
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.tower, 300, 125 ,null);
	}


}
