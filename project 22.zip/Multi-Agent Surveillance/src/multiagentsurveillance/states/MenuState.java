package multiagentsurveillance.states;

import java.awt.Graphics;

import multiagentsurveillance.Game;

public class MenuState extends State {

	public MenuState(Game game){
		super(game);
	}

	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
	}
	
}
