package multiagentsurveillance.states;

import java.awt.Graphics;

import multiagentsurveillance.Game;
import multiagentsurveillance.entities.creatures.Player;
import multiagentsurveillance.entities.creatures.Tower;
import multiagentsurveillance.worlds.World;

public class GameState extends State {
	
	private Player player;
	private World world;
	private Tower tower;
	
	public GameState(Game game){
		super(game);
		// player Start Position
		player = new Player(game, 200, 100);
		world = new World("res/worlds/world1.txt");
		tower = new Tower(game, 500,500);
	}
	
	@Override
	public void tick() {
		world.tick();
		player.tick();
		tower.tick();
	}

	@Override
	public void render(Graphics g) {
		world.render(g);
		player.render(g);
		tower.render(g);
	}

}
