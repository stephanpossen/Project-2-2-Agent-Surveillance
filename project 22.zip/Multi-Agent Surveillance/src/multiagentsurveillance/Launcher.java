package multiagentsurveillance;


public class Launcher {

	public static void main(String[] args){
		Game game = new Game("Multi-Agent Surveillance", 640, 350);
		game.start();
	}
	
}
